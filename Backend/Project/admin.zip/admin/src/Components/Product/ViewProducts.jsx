import React from 'react'

export default function ViewProducts() {
  return (
    <div>
      
    </div>
  )
}
