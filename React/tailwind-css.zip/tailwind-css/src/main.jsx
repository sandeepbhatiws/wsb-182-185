import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './assets/css/style.css'
import Header from './Components/Common/Header'
import { BrowserRouter, Route, Routes } from 'react-router'
import Home from './Components/Home'
import RootLayout from './Components/RootLayout'

createRoot(document.getElementById('root')).render(
  <>
    <BrowserRouter>
      <Routes>
        <Route element={<RootLayout/>}>
          <Route path='/' element={<Home/>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  </>,
)
