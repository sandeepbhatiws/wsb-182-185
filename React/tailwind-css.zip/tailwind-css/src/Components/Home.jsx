import React from 'react'
import MenProducts from './MenProducts'
import WomenProducts from './WomenProducts'

export default function Home() {
  return (
    <>
      <MenProducts/>
      <WomenProducts/>
    </>
  )
}
